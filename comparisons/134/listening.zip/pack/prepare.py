"""Run with numpy, scipy, ffmpeg, GNU time. See README for asset paths."""
import array, csv, hashlib, json, math, os, platform, resource, subprocess as sp, tarfile, time
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from scipy import signal
root=Path(__file__).resolve().parent.parent
os.chdir(root)
pack=Path('pack')
sources=Path('sources')
tools=Path('tools')
rate=48000
n=rate*6
t=np.arange(n)/rate
rng=np.random.default_rng(134)
def run(cmd, **opts):
    return sp.run([str(s) for s in cmd],check=True,**opts)
def ff(*args, **opts):
    return run(['ffmpeg','-nostdin','-loglevel','error','-y',*args],**opts)
def save(path,data):
    wavfile.write(path,rate,np.round(np.clip(data,-0.999,0.999)*32767).astype(np.int16))
def read(path):
    sr,data=wavfile.read(path)
    assert sr==rate
    return data.astype(float)/(32768 if data.dtype==np.int16 else 1)
def rms(data): return np.sqrt(np.mean(data**2))
def norm(data,level): return data*10**(level/20)/max(1e-9,rms(data))
voices={}
manifest={}
with tarfile.open(sources/'test-clean.tar.gz','r:gz') as corpus:
    by_speaker={}
    for f in corpus:
        if f.name.endswith('.flac'):
            speaker=f.name.split('/')[2]
            if speaker not in by_speaker and len(by_speaker)>=4: continue
            by_speaker.setdefault(speaker,[]).append(f)
            if len(by_speaker)==4 and all(len(group)>=3 for group in by_speaker.values()): break
    for speaker,group in by_speaker.items():
        chunks=[]
        used=[]
        for f in sorted(group,key=lambda item:item.name):
            pcm=ff('-i','pipe:0','-ar',rate,'-ac',1,'-f','f32le','pipe:1',input=corpus.extractfile(f).read(),stdout=sp.PIPE).stdout
            chunks.append(np.frombuffer(pcm,dtype='<f4'))
            used.append(f.name)
            if sum(map(len,chunks))>=n: break
        raw=np.concatenate(chunks)[:n]
        assert len(raw)==n
        voices[speaker]=norm(raw,-22)
        manifest[speaker]=used
speakers=list(voices)
white=rng.normal(size=n)
fan=norm(0.35*np.sin(2*np.pi*60*t)+signal.sosfilt(signal.butter(2,900,fs=rate,output='sos'),white),-29)
keys=np.zeros(n)
for start in rng.integers(0,n-4000,37):
    u=np.arange(2500)/rate
    keys[start:start+len(u)] += rng.uniform(0.1,0.3)*np.exp(-u/0.007)*(np.sin(2*np.pi*rng.uniform(900,3200)*u)+rng.normal(0,0.55,len(u)))
room=norm(signal.sosfilt(signal.butter(2,[180,1500],btype='bandpass',fs=rate,output='sos'),white)*np.maximum(0,np.sin(2*np.pi*.35*t)), -25)
cases=['clean','fan-hum','keyboard-taps','intermittent-room','room-echo','background-conversation','quiet-speech']
measurements=[]
sysaudio=.08*np.sin(2*np.pi*330*t)*(t%1<.4)
save(pack/'system.wav',sysaudio)
for i,kind in enumerate(cases):
    speaker=speakers[i%len(speakers)]
    v=voices[speaker]
    other=voices[speakers[(i+1)%len(speakers)]]
    echo=np.concatenate(([0]*5760,v[:-5760]))*.43+np.concatenate(([0]*11840,v[:-11840]))*.21
    raw=[v,v+fan,v+keys,v+room,v+echo,v+norm(other,-25),v*.18+fan*.2][i]
    raw*=min(1,.9/max(abs(raw)))
    d=pack/kind
    d.mkdir(exist_ok=True)
    save(d/'Original.wav',raw)
    raw=read(d/'Original.wav')
    variants={'Original':raw}
    for engine,cmd in [
        ('FFmpeg',['ffmpeg','-v','error','-y','-i',d/'Original.wav','-af','apad=pad_dur=0.1,highpass=f=80,afftdn=nf=-25:tn=1',d/'FFmpeg-raw.wav']),
        ('RNNoise',['ffmpeg','-v','error','-y','-i',d/'Original.wav','-af',f'apad=pad_dur=0.1,arnndn=m={tools}/bd.rnnn',d/'RNNoise-raw.wav']),
        ('DeepFilterNet3',[next(tools.glob('deep-filter-*')),'-D','-m',tools/'DeepFilterNet3_onnx.tar.gz','-o',d/'deep',d/'Original.wav'])]:
        (d/'deep').mkdir(exist_ok=True)
        timer=root/'timing'
        run(['/usr/bin/time','-f','%e %M','-o',timer,*cmd],stdout=sp.DEVNULL,stderr=sp.DEVNULL)
        secs,kib=timer.read_text().split()
        if engine=='DeepFilterNet3': (d/'deep'/'Original.wav').replace(d/'DeepFilterNet3-raw.wav')
        y=read(d/(engine+'-raw.wav'))
        corr=signal.correlate(y,raw,'full',method='fft')
        lo=n-1-2400
        lag=int(np.argmax(corr[lo:lo+4801])+lo-n+1)
        aligned=np.pad(y,(max(0,-lag),max(0,lag)+n))[max(0,lag):][:n]
        variants[engine]=aligned
        measurements.append(dict(case=kind,speaker=speaker,engine=engine,elapsed_s=secs,rtf=round(float(secs)/6,4),max_rss_KiB=kib,alignment_samples=lag))
    # Apply one gain to the whole clip, measured over reference speech-active samples.
    active=np.abs(v)>0.025
    gains={key:rms(raw[active])/max(1e-9,rms(y[active])) for key,y in variants.items()}
    headroom=min(1,.90/max(np.max(abs(y*gains[key])) for key,y in variants.items()))
    for key,y in variants.items():
        gain=gains[key]*headroom
        save(d/(key+'-listen.wav'),y*gain)
        if key!='Original':
            next(r for r in measurements if r['case']==kind and r['engine']==key)['gain_dB']=round(20*math.log10(gain),3)
    if kind=='fan-hum':
        for key,y in variants.items():
            # Lossless stereo stems, left mic, right system. Mono preview is a fixed gain sum.
            stems=np.column_stack((.65*y,read(pack/'system.wav')))
            save(d/(key+'-stems.wav'),stems)
            save(d/(key+'-mix.wav'),stems.sum(axis=1))
        systems=[wavfile.read(d/(key+'-stems.wav'))[1][:,1].tobytes() for key in variants]
        assert len(set(systems))==1
    (d/'deep').rmdir()
(pack/'sources.json').write_text(json.dumps(manifest,indent=2))
with (pack/'measurements.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=measurements[0])
    w.writeheader()
    w.writerows(measurements)
